Hi there!
Here it comes, new StepMix entry by Lisek, Tetris (Rock Version) by Soundshift grabbed from newgrounds with CC license.
Graphics are by me, created from scratch.
The song is a rock reincarnation of 8-bit Tetris theme.
Just like my previous works, every chart is quality-checked by Chmurek, the StepMix3 winner (the creator of Rockhill).

[Beginner][1]
Very easy, but certainly not boring. Some jumps and freezes are present.

[Light][2]
More focus on holds, but still easy. Added some really easy 1/4th streams for fun.

[Standard][5]
This chart is very easy to AAA. Easy crossover patterns, some 1/8th triplets.

[Heavy][7]
The main dish. Plain fun for DDR players, many jumps and holds make this chart really energetic.

[Challenge][8]
If you are looking for more, here it is. Even more jumps, holds and crossovers, great as a warmup song for ITG players.

